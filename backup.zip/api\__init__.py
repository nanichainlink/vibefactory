"""
Módulo principal de la API de VibeFactory.

Este paquete contiene los endpoints y modelos necesarios para la API REST de VibeFactory.
"""

__version__ = "0.1.0"
