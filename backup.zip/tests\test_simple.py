"""Simple test to verify the test environment is working."""

def test_simple():
    """A simple passing test."""
    assert 1 + 1 == 2
