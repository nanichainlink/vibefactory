import sqlite3

def create_example_schema(conn):
    cursor = conn.cursor()
    # Tabla de Mascotas
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Mascotas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        especie TEXT NOT NULL,
        raza TEXT,
        genero TEXT CHECK(genero IN ('H', 'M')),
        fecha_nacimiento DATE
    );
    """)
    # Tabla de Dueños
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Dueno (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        apellido TEXT NOT NULL,
        telefono TEXT
    );
    """)
    # Relación Mascota-Dueño (muchas mascotas pueden tener un dueño)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS MascotaDueno (
        mascota_id INTEGER,
        dueno_id INTEGER,
        PRIMARY KEY (mascota_id, dueno_id),
        FOREIGN KEY (mascota_id) REFERENCES Mascotas(id),
        FOREIGN KEY (dueno_id) REFERENCES Dueno(id)
    );
    """)
    # Tabla de Eventos (por ejemplo, visitas al veterinario, premios, etc.)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS Eventos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mascota_id INTEGER,
        tipo_evento TEXT NOT NULL,
        fecha DATE NOT NULL,
        descripcion TEXT,
        FOREIGN KEY (mascota_id) REFERENCES Mascotas(id)
    );
    """)
    conn.commit()

def insert_sample_data(conn):
    cursor = conn.cursor()
    # Dueños
    cursor.executemany("""
    INSERT INTO Dueno (nombre, apellido, telefono) VALUES (?, ?, ?)
    """, [
        ("Ana", "García", "600123456"),
        ("Luis", "Pérez", "600654321"),
        ("Marta", "López", "600987654"),
    ])
    # Mascotas
    cursor.executemany("""
    INSERT INTO Mascotas (nombre, especie, raza, genero, fecha_nacimiento) VALUES (?, ?, ?, ?, ?)
    """, [
        ("Luna", "Perro", "Labrador", "H", "2019-05-10"),
        ("Max", "Perro", "Bulldog", "M", "2018-07-22"),
        ("Mimi", "Gato", "Siamés", "H", "2020-03-15"),
        ("Rocky", "Perro", "Pastor Alemán", "M", "2017-11-30"),
        ("Nina", "Gato", "Persa", "H", "2021-01-05"),
    ])
    # Relación Mascota-Dueño
    cursor.executemany("""
    INSERT INTO MascotaDueno (mascota_id, dueno_id) VALUES (?, ?)
    """, [
        (1, 1),  # Luna - Ana
        (2, 2),  # Max - Luis
        (3, 1),  # Mimi - Ana
        (4, 3),  # Rocky - Marta
        (5, 2),  # Nina - Luis
    ])
    # Eventos
    cursor.executemany("""
    INSERT INTO Eventos (mascota_id, tipo_evento, fecha, descripcion) VALUES (?, ?, ?, ?)
    """, [
        (1, "Vacunación", "2020-06-15", "Vacuna antirrábica"),
        (2, "Premio", "2019-09-10", "Ganó concurso de obediencia"),
        (3, "Veterinario", "2021-04-20", "Revisión anual"),
        (4, "Vacunación", "2018-12-01", "Vacuna polivalente"),
        (5, "Premio", "2022-03-12", "Mejor disfraz en carnaval"),
    ])
    conn.commit()

def main():
    conn = sqlite3.connect("juego_sql.db")
    create_example_schema(conn)
    insert_sample_data(conn)
    print("Base de datos creada y poblada con datos de ejemplo.")
    conn.close()

if __name__ == "__main__":
    main()