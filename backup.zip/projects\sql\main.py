from app import App

def main():
    app = App()
    while True:
        print("1. Registrar usuario")
        print("2. Actualizar progreso")
        print("3. Obtener progreso")
        print("4. Salir")
        opcion = input("Ingrese una opción: ")
        
        if opcion == '1':
            nombre = input("Ingrese el nombre del usuario: ")
            progreso = input("Ingrese el progreso del usuario: ")
            app.registrar_usuario(nombre, progreso)
        elif opcion == '2':
            id_usuario = int(input("Ingrese el ID del usuario: "))
            progreso = input("Ingrese el nuevo progreso: ")
            app.actualizar_progreso_usuario(id_usuario, progreso)
        elif opcion == '3':
            nombre = input("Ingrese el nombre del usuario: ")
            progreso = app.obtener_progreso_usuario(nombre)
            if progreso:
                print(f"El progreso de {nombre} es: {progreso[0]}")
            else:
                print("No se encontró el usuario.")
        elif opcion == '4':
            app.cerrar_app()
            break
        else:
            print("Opción inválida.")

if __name__ == '__main__':
    main()