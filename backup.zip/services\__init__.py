"""
Módulo de servicios de VibeFactory.

Este paquete contiene la lógica de negocio principal de VibeFactory,
incluyendo la orquestación de agentes IA y la gestión de proyectos.
"""

__version__ = "0.1.0"
